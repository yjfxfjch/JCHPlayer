/************************************************************************
    This file is part of VLCWrapper.
    
    File:    CVlcDialogDlg.cpp
    Desc.:   CVlcDialogDlg Implementation.

	Author:  Alex Skoruppa
	Date:    08/10/2009
	Updated: 03/12/2012
	eM@il:   alex.skoruppa@googlemail.com

	VLCWrapper is distributed under the Code Project Open License (CPOL).

	You should have received a copy of the Code Project Open License
	along with VLCWrapper.  If not, see <http://www.codeproject.com/info/cpol10.aspx>.
************************************************************************/
#include "stdafx.h"
#include "VlcDialog.h"
#include "VlcDialogDlg.h"
#include <vlc/vlc.h>
#include "Version.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

class CAboutDlg : public CDialog
{
    CEdit     licencse_;
    CStatic   version_;
public:
	CAboutDlg();

	enum { IDD = IDD_ABOUTBOX };

	protected:
    virtual BOOL OnInitDialog();
	virtual void DoDataExchange(CDataExchange* pDX);

protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}

BOOL CAboutDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
    CString version;    
    version.Format("Version %s", FILE_VERSIONSTRING);
    version_.SetWindowText(version);
	CString license;
	license.LoadString(IDS_LICENCSE);
	licencse_.SetWindowText(license);
	return TRUE;
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
    DDX_Control(pDX, IDC_EDIT1, licencse_);
    DDX_Control(pDX, IDC_STATIC_VERSION, version_);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()

static void HandleVLCEvents(const VLCEvent* pEvt, void* pUserData)
{       
    CVlcDialogDlg* pDlg = reinterpret_cast<CVlcDialogDlg*>(pUserData); 
        
    switch(pEvt->type)
    {
    case libvlc_MediaPlayerTimeChanged:
        TRACE("VLC_EVT_TIME_CHANGED: new_time %d[ms]\n", pEvt->u.media_player_time_changed.new_time);
		if(pDlg)
			pDlg->UpdatePosition();
        break;
    }    
}

CVlcDialogDlg::CVlcDialogDlg(CWnd* pParent /*=NULL*/)
:   CDialog(CVlcDialogDlg::IDD, pParent),
    muteFlag_(false),
    length_(0),
    created_(false)
{
    //{{AFX_DATA_INIT(CVlcDialogDlg)
    //}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

CVlcDialogDlg::~CVlcDialogDlg()
{
}

void CVlcDialogDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
    //{{AFX_DATA_MAP(CVlcDialogDlg)
    DDX_Control(pDX, IDC_STATIC_MEDIA_CONTROL, mediaControlGroup_);
    DDX_Control(pDX, IDC_BUTTON_PLAY, buttonPlay_);
    DDX_Control(pDX, IDC_BUTTON_PAUSE, buttonPause_);
    DDX_Control(pDX, IDC_BUTTON_STOP, buttonStop_);
    DDX_Control(pDX, IDC_BUTTON_MUTE, buttonMute_);
    DDX_Control(pDX, IDC_BUTTON_LOAD, buttonOpen_);
	DDX_Control(pDX, IDC_STATIC_VLC, vlcControl_);
    DDX_Control(pDX, IDC_SLIDER_MEDIA, mediaSlider_);
    DDX_Control(pDX, IDC_STATIC_POSITION, mediaPosition_);
    DDX_Control(pDX, IDC_STATIC_VOLUME_TEXT, volumeText_);
    DDX_Control(pDX, IDC_SLIDER_VOLUME, volumeSlider_);
    DDX_Control(pDX, IDC_STATIC_VOLUME, volumeLevel_);
    //}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CVlcDialogDlg, CDialog)
    //{{AFX_MSG_MAP(CVlcDialogDlg)	
    ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()	
    ON_WM_HSCROLL()
	ON_WM_SHOWWINDOW()
    ON_WM_GETMINMAXINFO()
	ON_BN_CLICKED(IDC_BUTTON_PLAY, OnBnClickedButtonPlay)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnBnClickedButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_PAUSE, OnBnClickedButtonPause)
	ON_BN_CLICKED(IDC_BUTTON_LOAD, OnBnClickedButtonLoad)
    ON_BN_CLICKED(IDC_BUTTON_MUTE, OnBnClickedButtonMute)
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CVlcDialogDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// IDM_ABOUTBOX muss sich im Bereich der Systembefehle befinden.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString aboutMenu;
		BOOL nameIsValid = aboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(nameIsValid);
		if (!aboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, aboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);
    vlcPlayer_.SetOutputWindow((void*)vlcControl_.GetSafeHwnd());    
    vlcPlayer_.SetEventHandler(&HandleVLCEvents, this);
    volumeSlider_.SetRange(0,100);
    mediaSlider_.SetRange(0,100);
    int volume = vlcPlayer_.GetVolume();
    volumeSlider_.SetPos(volume);
    CString volumeString;
	volumeString.Format("%d", volume);
    volumeLevel_.SetWindowText(volumeString);

    // Set the icon buttons...
    buttonPlay_.SetIcon((HICON)LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_PLAY), IMAGE_ICON, 16, 16, LR_SHARED));
    buttonPause_.SetIcon((HICON)LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_PAUSE), IMAGE_ICON, 16, 16, LR_SHARED));
    buttonStop_.SetIcon((HICON)LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_STOP), IMAGE_ICON, 16, 16, LR_SHARED));
    noMuteIcon_=(HICON)LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_MUTE), IMAGE_ICON, 16, 16, LR_SHARED);
    muteIcon_=(HICON)LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_MUTE2), IMAGE_ICON, 16, 16, LR_SHARED);
    buttonMute_.SetIcon(noMuteIcon_);
    buttonOpen_.SetIcon((HICON)LoadImage(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_EJECT), IMAGE_ICON, 16, 16, LR_SHARED));

    // Save the all elements of the groupbox in list
    listDlgItems_.AddTail(&mediaControlGroup_);
    listDlgItems_.AddTail(&mediaSlider_);
    listDlgItems_.AddTail(&mediaPosition_);
    listDlgItems_.AddTail(&buttonPlay_);
    listDlgItems_.AddTail(&buttonPause_);
    listDlgItems_.AddTail(&buttonStop_);
    listDlgItems_.AddTail(&buttonMute_);
    listDlgItems_.AddTail(&buttonOpen_);    
    listDlgItems_.AddTail(&volumeText_);
    listDlgItems_.AddTail(&volumeSlider_);
    listDlgItems_.AddTail(&volumeLevel_);
    
    created_ = true;

    // Save actual dialog size
    CRect myRect;
    GetClientRect(&myRect);
    currentDlgSize_.cx = myRect.Width();
    currentDlgSize_.cy = myRect.Height();

    // Save minimum window size
    GetWindowRect(&myRect);
    minDlgSize_.cx = myRect.Width();
    minDlgSize_.cy = myRect.Height();

	return TRUE;
}

void CVlcDialogDlg::RecalcLayout(int cx, int cy)
{
    if(!created_)
        return;

    if(cx==0 && cy==0)
    {
        CRect rect;
        GetClientRect(&rect);
        
        cx=rect.Width();
        cy=rect.Height();
    }
    
    int controlsHeight = 120;
    int newHeight = cy - controlsHeight - 7;

    // Resize the VLC static control
    vlcControl_.MoveWindow(CRect(7,7,cx-7, newHeight));
        
    // calculate the displacement values
    RECT rect;
    mediaControlGroup_.GetWindowRect(&rect);
    ScreenToClient(&rect);
    int offsetX = rect.left;
    int groupWidth = rect.right-rect.left;
    int moveX = (cx - groupWidth) / 2 - offsetX;
    int moveY = cy - currentDlgSize_.cy;

    // Move all controls in list
    POSITION pos = listDlgItems_.GetHeadPosition();
    for(int i=0; i<listDlgItems_.GetCount(); i++)
    {
        CWnd* pMyWnd = listDlgItems_.GetNext(pos);
        if(pMyWnd)
        {            
            CRect myPos;
            pMyWnd->GetWindowRect(&myPos);
            ScreenToClient(myPos);            
            pMyWnd->SetWindowPos(0, myPos.left+moveX, myPos.top+moveY, 0, 0, SWP_SHOWWINDOW | SWP_NOSIZE | SWP_NOZORDER);            
        }
    }
    currentDlgSize_.cx = cx;
    currentDlgSize_.cy = cy;
}

void CVlcDialogDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CVlcDialogDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this);

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
		vlcControl_.RedrawWindow(NULL, NULL, RDW_ERASE | RDW_INVALIDATE | RDW_FRAME | RDW_ALLCHILDREN);
	}
}

HCURSOR CVlcDialogDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

void CVlcDialogDlg::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar)
{
    CSliderCtrl* pSlider=reinterpret_cast<CSliderCtrl*>(pScrollBar);

    if(*pSlider == volumeSlider_)
    {
        int pos = volumeSlider_.GetPos();
        vlcPlayer_.SetVolume(pos);
		CString volume;
		volume.Format("%d", pos);
        volumeLevel_.SetWindowText(volume);
        muteFlag_ = false;
        buttonMute_.SetIcon(noMuteIcon_);
    }

    if(*pSlider == mediaSlider_)
    {
        int pos = mediaSlider_.GetPos();
        vlcPlayer_.SetTime(length_/100*pos);
    }

    CDialog::OnHScroll(nSBCode, nPos, pScrollBar);
}

void CVlcDialogDlg::OnShowWindow(BOOL bShow, UINT nStatus)
{
	CDialog::OnShowWindow(bShow, nStatus);
}

void CVlcDialogDlg::OnBnClickedButtonPlay()
{
    vlcPlayer_.Play();
}

void CVlcDialogDlg::OnBnClickedButtonStop()
{
    vlcPlayer_.Stop();
    length_ = 0;
    mediaSlider_.SetPos(0);
    CString length;
    mediaPosition_.GetWindowText(length);
    length = CString("[00:00:00")+length.Right(10);
    mediaPosition_.SetWindowText(length);
}

void CVlcDialogDlg::OnBnClickedButtonPause()
{
    vlcPlayer_.Pause();
}

void CVlcDialogDlg::OnBnClickedButtonMute()
{   
    muteFlag_ = !vlcPlayer_.GetMute();
    (muteFlag_) ? buttonMute_.SetIcon(muteIcon_) : buttonMute_.SetIcon(noMuteIcon_);
    vlcPlayer_.Mute(muteFlag_);
}

void CVlcDialogDlg::OnBnClickedButtonLoad()
{
	CFileDialog dlgFile(TRUE);
	if(dlgFile.DoModal()==IDOK)
	{
		CString file = dlgFile.GetPathName();
        vlcPlayer_.OpenMedia((LPCTSTR)file);
        vlcPlayer_.Play();
        
        // Show filename as groupbox title
        if(file.GetLength()>80)
            file = CString("...") + file.Right(80);
        mediaControlGroup_.SetWindowText(file);
	}
}

void CVlcDialogDlg::OnOK()
{
}

void CVlcDialogDlg::UpdatePosition()
{
    length_ = vlcPlayer_.GetLength();
	int64_t newPosition = vlcPlayer_.GetTime();

    CTimeSpan length(static_cast<time_t>(length_/1000));
	CTimeSpan actualPosition(static_cast<time_t>(newPosition/1000));
    
    CString lengthString;
    lengthString.Format("[%02d:%02d:%02d/%02d:%02d:%02d]",
		                actualPosition.GetHours(), actualPosition.GetMinutes(), actualPosition.GetSeconds(),
					    length.GetHours(), length.GetMinutes(), length.GetSeconds());

    mediaPosition_.SetWindowText(lengthString);

    int newSliderPos = length_ ? static_cast<int>((static_cast<double>(newPosition)/static_cast<double>(length_) * 100)) : 0;
    mediaSlider_.SetPos(newSliderPos);
}

void CVlcDialogDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
    RecalcLayout(cx,cy);		
	Invalidate();
}

void CVlcDialogDlg::OnGetMinMaxInfo( MINMAXINFO FAR* lpMMI )
{
    if(created_)
    {
        lpMMI->ptMinTrackSize.x =  minDlgSize_.cx;
        lpMMI->ptMinTrackSize.y =  minDlgSize_.cy;
    }
}
