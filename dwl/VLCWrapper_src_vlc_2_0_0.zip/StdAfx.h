#if !defined(AFX_STDAFX_H__414F76F0_99FE_4700_B021_0F4A435B314F__INCLUDED_)
#define AFX_STDAFX_H__414F76F0_99FE_4700_B021_0F4A435B314F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN

#include <afxwin.h>
#include <afxext.h>
#include <afxdtctl.h>
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>
#endif // _AFX_NO_AFXCMN_SUPPORT

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_STDAFX_H__414F76F0_99FE_4700_B021_0F4A435B314F__INCLUDED_)
