/************************************************************************
    This file is part of VLCWrapper.
    
    File:   CVlcDialogApp.cpp
    Desc.:  CVlcDialogApp Implementation.

	Author:  Alex Skoruppa
	Date:    08/10/2009
	Updated: 03/12/2012
	eM@il:   alex.skoruppa@googlemail.com

	VLCWrapper is distributed under the Code Project Open License (CPOL).

	You should have received a copy of the Code Project Open License
	along with VLCWrapper.  If not, see <http://www.codeproject.com/info/cpol10.aspx>.
************************************************************************/
#include "stdafx.h"
#include "VlcDialog.h"
#include "VlcDialogDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BEGIN_MESSAGE_MAP(CVlcDialogApp, CWinApp)
	//{{AFX_MSG_MAP(CVlcDialogApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

CVlcDialogApp::CVlcDialogApp()
{
}

CVlcDialogApp theApp;

BOOL CVlcDialogApp::InitInstance()
{
#if _MSC_VER < 1600
  #ifdef _AFXDLL
	  Enable3dControls();
  #else
	  Enable3dControlsStatic();
  #endif
#endif

	CVlcDialogDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	return FALSE;
}
