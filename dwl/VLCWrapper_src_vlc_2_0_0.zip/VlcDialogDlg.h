/************************************************************************
    This file is part of VLCWrapper.
    
    File:    CVlcDialogDlg.h
    Desc.:   CVlcDialogDlg - A simple dialog based media player application.

	Author:  Alex Skoruppa
	Date:    08/10/2009
	Updated: 03/12/2012
	eM@il:   alex.skoruppa@googlemail.com

	VLCWrapper is distributed under the Code Project Open License (CPOL).

	You should have received a copy of the Code Project Open License
	along with VLCWrapper.  If not, see <http://www.codeproject.com/info/cpol10.aspx>.
************************************************************************/
#pragma once
#include "afxwin.h"
#include <afxtempl.h>
#include "VLCWrapper.h"

class CVlcDialogDlg : public CDialog
{
    VLCWrapper          vlcPlayer_;
    bool                muteFlag_;
    int64_t             length_;    
    CList<CWnd*, CWnd*> listDlgItems_;
    CSize               currentDlgSize_;
    CSize               minDlgSize_;
    HICON               noMuteIcon_;
    HICON               muteIcon_;
    bool                created_;

    //{{AFX_DATA(CVlcDialogDlg)
    CButton     mediaControlGroup_;
    CButton     buttonPlay_;
    CButton     buttonPause_;
    CButton     buttonStop_;
    CButton     buttonMute_;
    CButton     buttonOpen_;
    CStatic     vlcControl_;
    CStatic     volumeText_;
    CStatic     volumeLevel_;
    CStatic     mediaPosition_;
    CSliderCtrl mediaSlider_;
    CSliderCtrl volumeSlider_;
    //}}AFX_DATA

public:
	CVlcDialogDlg(CWnd* pParent = NULL);
	~CVlcDialogDlg();

    void UpdatePosition();

	enum { IDD = IDD_VLCDIALOG_DIALOG };

protected:
    //{{AFX_VIRTUAL(CButtonDialog)
	virtual void DoDataExchange(CDataExchange* pDX);
    //}}AFX_VIRTUAL
	virtual void OnOK();
	HICON m_hIcon;

    //{{AFX_MSG(CVlcDialogDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
    afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
    afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	afx_msg void OnSize(UINT nType, int cx, int cy);
    afx_msg void OnGetMinMaxInfo( MINMAXINFO FAR* lpMMI );
	//}}AFX_MSG
	afx_msg void OnBnClickedButtonPlay();
	afx_msg void OnBnClickedButtonStop();
	afx_msg void OnBnClickedButtonPause();
    afx_msg void OnBnClickedButtonMute();
	afx_msg void OnBnClickedButtonLoad();        
	DECLARE_MESSAGE_MAP()
    
    void RecalcLayout(int cx, int cy);
};
