/************************************************************************
    This file is part of VLCWrapper.
    
    File:   CVlcDialogApp.h
    Desc.:  CVlcDialogApp - A simple dialog based media player application.

    Author:  Alex Skoruppa
    Date:    08/10/2009
    Updated: 03/12/2012
    eM@il:   alex.skoruppa@googlemail.com

    VLCWrapper is distributed under the Code Project Open License (CPOL).
     
    You should have received a copy of the Code Project Open License
    along with VLCWrapper.  If not, see <http://www.codeproject.com/info/cpol10.aspx>.
	
************************************************************************/
#if !defined(AFX_VLCDIALOG_H__BC3D179D_F4CF_4D9F_B724_A085F58ED405__INCLUDED_)
#define AFX_VLCDIALOG_H__BC3D179D_F4CF_4D9F_B724_A085F58ED405__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "stdafx.h"
#include "resource.h"

class CVlcDialogApp : public CWinApp
{
public:
	CVlcDialogApp();
	
	//{{AFX_VIRTUAL(CVlcDialogApp)	
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CVlcDialogApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
#endif // !defined(AFX_VLCDIALOG_H__BC3D179D_F4CF_4D9F_B724_A085F58ED405__INCLUDED_)
