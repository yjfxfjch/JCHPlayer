//{{NO_DEPENDENCIES}}
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_VLCDIALOG_DIALOG            102
#define IDS_LICENCSE                    102
#define IDR_MAINFRAME                   128
#define IDI_MUTE                        130
#define IDI_EJECT                       131
#define IDI_PAUSE                       132
#define IDI_PLAY                        133
#define IDI_STOP                        134
#define IDI_MUTE2                       135
#define IDC_STATIC_VLC                  1001
#define IDC_BUTTON_PLAY                 1002
#define IDC_BUTTON_STOP                 1003
#define IDC_BUTTON_PAUSE                1004
#define IDC_BUTTON_LOAD                 1005
#define IDC_BUTTON_MUTE                 1006
#define IDC_SLIDER_MEDIA                1007
#define IDC_SLIDER_VOLUME               1008
#define IDC_STATIC_VOLUME               1009
#define IDC_STATIC_POSITION             1010
#define IDC_EDIT1                       1011
#define IDC_STATIC_MEDIA_CONTROL        1012
#define IDC_STATIC_VOLUME_TEXT          1013
#define IDC_STATIC_VERSION              1014

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        136
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
