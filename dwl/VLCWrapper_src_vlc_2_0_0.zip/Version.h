/************************************************************************    
    File:   Version.h
    Desc.:  Easy versioning of VlcDialog over this header, instead of
            editing rc with assistant.

    Author:  Alex Skoruppa
    Date:    08/18/2009
    Updatet: 03/12/2012
    eM@il:   alex.skoruppa@googlemail.com
************************************************************************/
#define FILE_VERSIONSTRING     "1.4.0.0\0"
#define FILE_MAJOR             1
#define FILE_MINOR             4
#define FILE_BUILD             0
#define FILE_REVISION          0

#define COMPANY_NAME      "Alex Skoruppa\0"
#define LEGAL_COPYRIGHT   "Copyright (C) 2009-2012 Alex Skoruppa\0"
#define LEGAL_TRADEMARKS  "\0"
#define FILE_DESCRIPTION  "VlcDialog\0"
#define INTERNAL_NAME     "VlcDialog\0"
#define ORIGINAL_FILENAME "VlcDialog.exe\0"
#define PRODUCT_NAME      "VlcDialog\0"
#define COMMENTS          "A media player using the VLCWrapper.\0"

